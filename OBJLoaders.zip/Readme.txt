If the browser cannot access to XMLHttpRequest at local file, use python3 -m http.server 8000 to set up a localhost:8000 server.

Here is simple OBJ file format. Most of obj files follow this rule. Some files may have additional data, but it can be ignored.
The texture sometimes looks weird. You can try to vertically flip the image to get the correct texture.

OBJ file format

-------------------------------------------------------
v is vertex

v coordX, coordY, coordZ
v ...
-------------------------------------------------------
vn is normal

vn normalU, normalV, normalW
vn ...
-------------------------------------------------------
vt is texture coordinate

vt texCoordX, texCoordY
vt ...
-------------------------------------------------------
use the material. material_name is from .mtl file

usemtl material_name
-------------------------------------------------------
Draw triangle fan for the vertex on the same line.

f (vertex index/ texture coordinate index/ normal index) * n

For example, if we have f 1/2/3 4/5/6 7/8/9 10/11/12, we will draw two triangles with the vertices 1,4,7 and 1,7,10.

===================================================

MTL file format

If this file only has Ka, Kd, Ks, you should use objLoader.
If this file has map_Ka, map_Kd, map_Ks, you should use objLoaderWithTexture.

Only Ka, Kd, Ks => they are color
With map_Ka, map_Kd, map_Ks => Ka*texture(map_Ka, texCoord) + Kd*texture(map_Kd, texCoord) + Ks*texture(map_Ks, texCoord) are color
You should use them to replace part of the lighting equation.