//////////////////////////////////////////////////////////////////
//
//  CSE 5542 OBJ Loader
//  

var gl;
var shaderProgram;

//////////// Init OpenGL Context etc. ///////////////

function initGL(canvas) {
    try {
        gl = canvas.getContext("experimental-webgl");
        gl.viewportWidth = canvas.width;
        gl.viewportHeight = canvas.height;
    } catch (e) {
    }
    if (!gl) {
        alert("Could not initialise WebGL, sorry :-(");
    }
}

///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////

var cubeVertexPositionBuffer;
var cubeVertexIndexBuffer;
var cubeVertexColorBuffer;

////////////////    Initialize VBO  ////////////////////////

function initCubeBuffers() {
    cubeVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVertexPositionBuffer);
    var vertices = [
        0.5, 0.5, -.5,
        -0.5, 0.5, -.5,
        - 0.5, -0.5, -.5,
        0.5, -0.5, -.5,
        0.5, 0.5, .5,
        -0.5, 0.5, .5,
        -0.5, -0.5, .5,
        0.5, -0.5, .5
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    cubeVertexPositionBuffer.itemSize = 3;
    cubeVertexPositionBuffer.numItems = 8;

    var indices = [0, 1, 2, 0, 2, 3, 0, 3, 7, 0, 7, 4, 6, 2, 3, 6, 3, 7, 5, 1, 2, 5, 2, 6, 5, 1, 0, 5, 0, 4, 5, 6, 7, 5, 7, 4];
    cubeVertexIndexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, cubeVertexIndexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices), gl.STATIC_DRAW);
    cubeVertexIndexBuffer.itemSize = 1;
    cubeVertexIndexBuffer.numItems = 36;   //36 indices, 3 per triangle, so 12 triangles 

    cubeVertexColorBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVertexColorBuffer);
    var colors = [
        0.0, 0.0, 1.0,
        0.0, 0.0, 1.0,
        1.0, 0.0, 0.0,
        1.0, 0.0, 0.0,
        0.0, 0.0, 1.0,
        0.0, 0.0, 1.0,
        1.0, 0.0, 0.0,
        1.0, 0.0, 0.0
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);
    cubeVertexColorBuffer.itemSize = 3;
    cubeVertexColorBuffer.numItems = 8;
}

const objSrc = "Table And Chairs.obj";
const mtlSrc = "Table And Chairs.mtl";

function initOBJLoader(objSrc, mtlSrc) {
    var request = new XMLHttpRequest();
    request.open("GET", objSrc);
    request.onreadystatechange =
        function () {
            if (request.readyState == 4) {
                console.log("state =" + request.readyState);
                mtlLoader(request.responseText, mtlSrc);
            }
        }
    request.send();
}

function mtlLoader(objText, mtlSrc) {
    var request = new XMLHttpRequest();
    request.open("GET", mtlSrc);
    request.onreadystatechange =
        function () {
            if (request.readyState == 4) {
                console.log("state =" + request.readyState);
                var obj = parseOBJ(objText);
                var mtl = parseMTL(request.responseText);
                initOBJBuffers(obj, mtl);
            }
        }
    request.send();
}

var objVertexPositionBuffers = [];
var objVertexNormalBuffers = [];
var mtlKa = [];
var mtlKd = [];
var mtlKs = [];
var mtlShininess = [];

function initOBJBuffers(objData, mtlData) {
    // console.log(objData);
    // console.log(mtlData);
    for(var geometry of objData.geometries) {
        var curVertexPositionBuffers = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, curVertexPositionBuffers);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(geometry.data.position), gl.STATIC_DRAW);
        curVertexPositionBuffers.itemSize = 3;
        curVertexPositionBuffers.numItems = geometry.data.position.length/3;
        objVertexPositionBuffers.push(curVertexPositionBuffers);

        var curVertexNormalBuffers = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, curVertexNormalBuffers);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(geometry.data.normal), gl.STATIC_DRAW);
        curVertexNormalBuffers.itemSize = 3;
        curVertexNormalBuffers.numItems = geometry.data.normal.length/3;
        objVertexNormalBuffers.push(curVertexNormalBuffers);

        mtlKa.push(mtlData[geometry.material].ambient);
        mtlKd.push(mtlData[geometry.material].diffuse);
        mtlKs.push(mtlData[geometry.material].specular);
        mtlShininess.push(mtlData[geometry.material].shininess);
    }
}

///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////

var vMatrix = mat4.create(); // view matrix
var mMatrix = mat4.create();  // model matrix
var mvMatrix = mat4.create();  // modelview matrix
var pMatrix = mat4.create();  //projection matrix 
var camera_phi = 30;
var camera_theta = 90;
var camera_dis = 8;


function setMatrixUniforms(mv, p) {
    gl.uniformMatrix4fv(shaderProgram.mvMatrixUniform, false, mv);
    gl.uniformMatrix4fv(shaderProgram.pMatrixUniform, false, p);
}

function degToRad(degrees) {
    return degrees * Math.PI / 180;
}

//////////////////////////////////////////////////////////////

function pushMatrix(stack, m) {
    var copy = mat4.create(m);  //necessary because javascript only does shallow push 
    stack.push(copy);
}

function popMatrix(stack) {
    return (stack.pop());
}

///////////////////////////////////////////////////////////////

function drawCube(m) {
    var mv = mat4.create();
    mat4.multiply(vMatrix, m, mv);
    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVertexPositionBuffer);
    gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, cubeVertexPositionBuffer.itemSize, gl.FLOAT, false, 0, 0);

    gl.enableVertexAttribArray(shaderProgram.vertexColorAttribute);
    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVertexColorBuffer);
    gl.vertexAttribPointer(shaderProgram.vertexColorAttribute,cubeVertexColorBuffer.itemSize, gl.FLOAT, false, 0, 0);

    // draw elementary arrays - triangle indices 
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, cubeVertexIndexBuffer);
    
    gl.uniform1i(shaderProgram.colorMode, 1);
    setMatrixUniforms(mv, pMatrix);   // pass the modelview mattrix and projection matrix to the shader

    gl.drawElements(gl.TRIANGLES, cubeVertexIndexBuffer.numItems, gl.UNSIGNED_SHORT, 0);
}

function drawOBJ(m) {
    var mv = mat4.create();
    mat4.multiply(vMatrix, m, mv);
    gl.enableVertexAttribArray(shaderProgram.vertexColorAttribute);

    for(var i = 0; i < objVertexPositionBuffers.length; i++) {
        gl.bindBuffer(gl.ARRAY_BUFFER, objVertexPositionBuffers[i]);
        gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, objVertexPositionBuffers[i].itemSize, gl.FLOAT, false, 0, 0);

        gl.disableVertexAttribArray(shaderProgram.vertexColorAttribute);

        gl.uniform1i(shaderProgram.colorMode, 0);
        setMatrixUniforms(mv, pMatrix);   // pass the modelview mattrix and projection matrix to the shader

        gl.uniform4f(shaderProgram.ambient_coefUniform, mtlKa[i][0], mtlKa[i][1], mtlKa[i][2], 1.0); 
        gl.uniform4f(shaderProgram.diffuse_coefUniform, mtlKd[i][0], mtlKd[i][1], mtlKd[i][2], 1.0); 
        gl.uniform4f(shaderProgram.specular_coefUniform, mtlKs[i][0], mtlKs[i][1], mtlKs[i][2], 1.0); 

        gl.drawArrays(gl.TRIANGLES, 0, objVertexPositionBuffers[i].numItems);
    }
    
}

function setUniformColor(color) {
    gl.disableVertexAttribArray(shaderProgram.vertexColorAttribute);
    gl.uniform1i(shaderProgram.colorMode, 0);
    gl.uniform4fv(shaderProgram.uColor, color);
}

function drawScene() {
    gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    mat4.perspective(60, 1.0, 0.1, 100, pMatrix);  // set up the projection matrix 

    var cphi = degToRad(camera_phi);
    var ctheta = degToRad(camera_theta);
    var camera_pos = [camera_dis*Math.cos(cphi)*Math.cos(ctheta), camera_dis*Math.sin(cphi), camera_dis*Math.cos(cphi)*Math.sin(ctheta)];
    mat4.identity(vMatrix);
    vMatrix = mat4.lookAt(camera_pos, [0, 0, 0], [0, 1, 0], vMatrix);	// set up the view matrix, multiply into the modelview matrix

    var floorMatrix = mat4.create();
    mat4.identity(floorMatrix);
    floorMatrix = mat4.scale(floorMatrix, [10, 2, 10]);
    drawCube(floorMatrix);

    var objMatrix = mat4.create();
    mat4.identity(objMatrix);
    objMatrix = mat4.scale(objMatrix, [2, 2, 2]);
    drawOBJ(objMatrix);
}


///////////////////////////////////////////////////////////////

var lastMouseX = 0, lastMouseY = 0;

///////////////////////////////////////////////////////////////

function onDocumentMouseDown(event) {
    event.preventDefault();
    document.addEventListener('mousemove', onDocumentMouseMove, false);
    document.addEventListener('mouseup', onDocumentMouseUp, false);
    document.addEventListener('mouseout', onDocumentMouseOut, false);
    var mouseX = event.clientX;
    var mouseY = event.clientY;

    lastMouseX = mouseX;
    lastMouseY = mouseY;
    drawScene();
}

function onDocumentMouseMove(event) {
    var mouseX = event.clientX;
    var mouseY = event.clientY;

    var diffX = mouseX - lastMouseX;
    var diffY = mouseY - lastMouseY;

    camera_theta = camera_theta + diffX/5;
    camera_phi = camera_phi + diffY/5;
    if(camera_phi > 85) camera_phi = 85;
    if(camera_phi < -30) camera_phi = -30;

    lastMouseX = mouseX;
    lastMouseY = mouseY;

    drawScene();
}

function onDocumentMouseUp(event) {
    document.removeEventListener('mousemove', onDocumentMouseMove, false);
    document.removeEventListener('mouseup', onDocumentMouseUp, false);
    document.removeEventListener('mouseout', onDocumentMouseOut, false);
}

function onDocumentMouseOut(event) {
    document.removeEventListener('mousemove', onDocumentMouseMove, false);
    document.removeEventListener('mouseup', onDocumentMouseUp, false);
    document.removeEventListener('mouseout', onDocumentMouseOut, false);
}

///////////////////////////////////////////////////////////////

function webGLStart() {
    var canvas = document.getElementById("obj_loader");
    initGL(canvas);
    initShaders();

    gl.enable(gl.DEPTH_TEST);

    shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");
    gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);
    shaderProgram.vertexColorAttribute = gl.getAttribLocation(shaderProgram, "aVertexColor");
    gl.enableVertexAttribArray(shaderProgram.vertexColorAttribute);
    shaderProgram.uColor = gl.getUniformLocation(shaderProgram, "uColor");
    shaderProgram.colorMode = gl.getUniformLocation(shaderProgram, "colorMode");

    shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");
    shaderProgram.pMatrixUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");

    shaderProgram.ambient_coefUniform = gl.getUniformLocation(shaderProgram, "ambient_coef");
    shaderProgram.diffuse_coefUniform = gl.getUniformLocation(shaderProgram, "diffuse_coef");
    shaderProgram.specular_coefUniform = gl.getUniformLocation(shaderProgram, "specular_coef");

    initCubeBuffers();
    initOBJLoader(objSrc, mtlSrc);

    bodyMatrix = mat4.create();
    mat4.identity(bodyMatrix);

    gl.clearColor(0.0, 0.0, 0.0, 1.0);

    document.addEventListener('mousedown', onDocumentMouseDown,false);

    drawScene();
}

function BG(red, green, blue) {
    gl.clearColor(red, green, blue, 1.0);
    drawScene();
}